export class Note{
    id: number;
    noteTitle: string;
    noteContent : string;
}